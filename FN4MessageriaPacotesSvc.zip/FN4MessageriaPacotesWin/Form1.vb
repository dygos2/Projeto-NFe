﻿Imports FN4MessageriaPacotesCtl.envio_emails

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim mon As New FN4MessageriaPacotesCtl.envio_emails
        mon.run()

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
