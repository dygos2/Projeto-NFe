﻿Public Class AssemblyInfo
    '   <Assembly:  log4net.Config.XMLConfigurator (ConfigFile: = " Log4NetAssembly1.exe.log4net " ,  Assista: = True) >

End Class
